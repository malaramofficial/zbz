// Unified AI Mentor controller
// This file provides a single exported function `handleMentorMessage`
// that other parts of the app can import to send user messages to the AI flows.
// It performs minimal orchestration: applies initial prompt, appends memory,
// and calls existing flow helpers if present.

import fs from 'fs';
import path from 'path';
// Try to import existing flows if they exist
let initialPrompt;
try {
  initialPrompt = require('../flows/ai-mentor-initial-prompt').default;
} catch (e) {
  initialPrompt = async () => ({ role: 'system', content: 'You are a friendly AI tutor.' });
}

let chatFlow;
try {
  chatFlow = require('../flows/ai-mentor-chat-flow').default;
} catch (e) {
  chatFlow = async ({ messages }) => {
    // placeholder: echo last user message with guidance
    const last = messages.filter(m=>m.role==='user').slice(-1)[0];
    return { role: 'assistant', content: `I heard: "${last?.content || ''}" — how can I help further?` };
  };
}

export async function handleMentorMessage({ userId, message, memory=[] }) {
  // Build messages array
  const systemPrompt = await initialPrompt();
  const messages = [systemPrompt, ...memory, { role: 'user', content: message }];
  // Call chatFlow (existing flow expected to return assistant message)
  const assistant = await chatFlow({ userId, messages });
  return assistant;
}

export default handleMentorMessage;
