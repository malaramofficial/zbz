// Example NextAuth route (placeholder)
// To enable: install next-auth and set NEXTAUTH_SECRET + GOOGLE_CLIENT_ID/SECRET in env.
/*
import NextAuth from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';

export default NextAuth({
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    }),
  ],
  secret: process.env.NEXTAUTH_SECRET,
});
*/
export default function handler(req, res) {
  res.status(200).json({ message: 'NextAuth placeholder. Configure next-auth and uncomment code.' });
}
