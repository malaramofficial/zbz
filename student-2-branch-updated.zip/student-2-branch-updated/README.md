# Firebase Studio

This is a NextJS starter in Firebase Studio.

To get started, take a look at src/app/page.tsx.


## AI Tutor App - Setup Notes (Added)

This repository has been updated to target an **AI Tutor App** setup (Mode: Mixed, Login: Google Auth, Backend: Firebase, UI: Dashboard + Premium).

### Quick start
1. Copy `.env.local.example` to `.env.local` and fill the values (Firebase project + Google OAuth credentials).
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run locally:
   ```bash
   npm run dev
   ```

### Firebase
- The file `src/lib/firebase.ts` initializes Firebase for client-side usage.
- For server-side admin tasks, provide `FIREBASE_SERVICE_ACCOUNT_JSON` in your environment or use deployment secrets.

### Authentication
- This template expects Google OAuth for login (via NextAuth or Firebase Auth). Configure Google OAuth credentials in Google Cloud Console and set `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`.

### AI Flows
- A unified controller was added at `src/ai/mentor/index.ts`. It wraps existing flow files if present. You can call it like:
  ```ts
  import handleMentorMessage from 'src/ai/mentor';
  const response = await handleMentorMessage({ userId: 'uid', message: 'Explain chapters of calculus', memory: [] });
  ```

### What I changed
- Removed duplicate `src/tailwind.config.ts` (if it existed) to avoid conflicts with root `tailwind.config.ts`.
- Added `.env.local.example`, `src/lib/firebase.ts`, and `src/ai/mentor/index.ts`.
- Minor README improvements and setup instructions.

If you'd like, I can:
- Integrate NextAuth Google provider config and example API routes.
- Add Firestore collections (users, sessions, messages) scaffolding and APIs.
- Create a dashboard UI with Tailwind + premium components.
